# PlaywrightAutomation
Capitec Automation training - Playwright JS Automation Testing from Scratch with Framework
